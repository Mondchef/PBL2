package vendas;
public class Batedeira extends Eletrodomestico implements Helicoidal {
    private int helices;

    public Batedeira(String marca, double preço, int voltagem) {
        super(marca, preço, voltagem);
    }
    public Batedeira(String marca, int voltagem) {
        super(marca, voltagem);
    }

    public int getHelices() {
        return helices;
    }

    public void setHelices(int helices) {
        this.helices = helices;
    }

    
    @Override
        public double CalcDesconto(int mes){
            if(mes == 12 ){
                this.preço = this.preço * 0.8f;   
        }return this.preço;
    }

    @Override
    public float QuantidadeMedia(int quant, int capacidade){
        return quant/(capacidade*this.helices);    
    }
}
