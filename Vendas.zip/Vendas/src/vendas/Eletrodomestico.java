package vendas;
public abstract class Eletrodomestico{
    protected String marca;
    protected double preço;
    protected int voltagem;
    
    public Eletrodomestico (String marca, double preço, int voltagem){
        this.marca = marca;
        this.preço = preço;
        this.voltagem = voltagem;
    }
    public Eletrodomestico(String marca, int voltagem){
        this.marca = marca;
        this.voltagem = voltagem;
    }
    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public double getPreço() {
        return preço;
    }

    public void setPreço(int preço) {
        this.preço = preço;
    }

    public int getVoltagem() {
        return voltagem;
    }

    public void setVoltagem(int voltagem) {
        this.voltagem = voltagem;
    }
    public double CalcDesconto(int mes){
        return this.preço;
    }
    
}
