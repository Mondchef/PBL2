package vendas;
public interface Helicoidal {
    public float QuantidadeMedia(int quant, int capacidade);
    
}
