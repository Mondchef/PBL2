package vendas;
public class Ferro extends Eletrodomestico {

    public Ferro(String marca, double preço, int voltagem) {
        super(marca, preço, voltagem);
    }
       public Ferro(String marca, int voltagem) {
        super(marca, voltagem);
    }
       
    @Override
    public double CalcDesconto(int mes){
        if(mes == 3 ){
            this.preço = this.preço * 0.85f;   
        }return this.preço;
    }
}
