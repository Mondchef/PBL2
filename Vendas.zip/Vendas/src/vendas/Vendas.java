package vendas;
import javax.swing.JOptionPane;
public class Vendas {
    public static void main(String[] args) { 
       String comprar;
       String eletro;
       int volts;
       double preço;
       Object[] volt = {"110", "220"};
       Object[] volt2 = {"110","220","5"};
       Object[] compra = {"Loja","Fabrica"};
       Object[] objeto = {"Liquidificador", "Batedeira","Ferro de Passar"};
       Object Loja = "Loja", Fabrica = "Fabrica";
       comprar = (String) JOptionPane.showInputDialog(null, "Informe onde irá comprar", "FERNANDES ELETRO",0, null, compra, null);
           eletro = (String) JOptionPane.showInputDialog(null, "Agora informe o eletrodomestico que deseja", "FERNANDES ELETRO",0, null, objeto, null);
           if((compra).equals(Loja)){
           if((eletro).equals("Liquidificador")){   
               String marca = JOptionPane.showInputDialog("Informe a marca do liquidificador");
               preço = Double.parseDouble(JOptionPane.showInputDialog("Informe o preço do liquidificador"));  
               volts = (int) JOptionPane.showInputDialog(null, "Agora informe a voltagem do equipamento", "FERNANDES ELETRO",0, null, volt, null);
               Liquidificador l = new Liquidificador(marca, preço, volts);
               l.preço = Integer.parseInt(JOptionPane.showInputDialog("Diga o número do mês da compra"));
               l.getTampa().setCor(JOptionPane.showInputDialog("Diga a cor da tampa do liquidificador"));
               l.getTampa().setDescrição("Descreva a tampa");
               System.out.println("A marca do liquidificar é " +l.getMarca()+ "O preço é original:" +l.getPreço()+ "O preço com desconto"+l.CalcDesconto(8)+"A cor da tampa é:"+l.getTampa().getCor()+"A descrição é"+l.getTampa().getDescrição() );
           }
           if((eletro).equals("Batedeira")){
               String marca = JOptionPane.showInputDialog("Informe a marca do liquidificador");
               preço = Double.parseDouble(JOptionPane.showInputDialog("Informe o preço do liquidificador"));  
               volts = (int) JOptionPane.showInputDialog(null, "Agora informe a voltagem do equipamento", "FERNANDES ELETRO",0, null, volt, null);
               Liquidificador l = new Liquidificador(marca, preço, volts);
               l.preço = Integer.parseInt(JOptionPane.showInputDialog("Diga o número do mês da compra"));
               l.getTampa().setCor(JOptionPane.showInputDialog("Diga a cor da tampa do liquidificador"));
               l.getTampa().setDescrição("Descreva a tampa");
               System.out.println("A marca do liquidificar é " +l.getMarca()+ "O preço é original:" +l.getPreço()+ "O preço com desconto"+l.CalcDesconto(8)+"A cor da tampa é:"+l.getTampa().getCor()+"A descrição é"+l.getTampa().getDescrição() );
           }
               if((eletro).equals("Batedeira")){
               String marca = JOptionPane.showInputDialog("Informe a marca da batedeira");
               preço = Double.parseDouble(JOptionPane.showInputDialog("Informe o preço do liquidificador"));  
               volts = (int) JOptionPane.showInputDialog(null, "Agora informe a voltagem do equipamento", "FERNANDES ELETRO",0, null, volt2, null);
               Liquidificador l = new Liquidificador(marca, preço, volts);
               l.preço = Integer.parseInt(JOptionPane.showInputDialog("Diga o número do mês da compra"));
               l.getTampa().setCor(JOptionPane.showInputDialog("Diga a cor da tampa do liquidificador"));
               l.getTampa().setDescrição("Descreva a tampa");
               System.out.println("A marca do liquidificar é " +l.getMarca()+ "O preço é original:" +l.getPreço()+ "O preço com desconto"+l.CalcDesconto(8)+"A cor da tampa é:"+l.getTampa().getCor()+"A descrição é"+l.getTampa().getDescrição() );
               
               
           }
        }
           if((compra).equals(Fabrica)){
           if((eletro).equals("Liquidificador")){   
               String marca = JOptionPane.showInputDialog("Informe a marca do liquidificador");
               volts = (int) JOptionPane.showInputDialog(null, "Agora informe a voltagem do equipamento", "FERNANDES ELETRO",0, null, volt, null);
               Liquidificador l = new Liquidificador(marca, volts);
               l.getTampa().setCor(JOptionPane.showInputDialog("Diga a cor da tampa do liquidificador"));
               l.getTampa().setDescrição("Descreva a tampa");
               System.out.println("A marca do liquidificar é " +l.getMarca()+ "O preço é original:" +l.getPreço()+ "O preço com desconto"+l.CalcDesconto(8)+"A cor da tampa é:"+l.getTampa().getCor()+"A descrição é"+l.getTampa().getDescrição() );
           }
           if((eletro).equals("Batedeira")){
               String marca = JOptionPane.showInputDialog("Informe a marca do liquidificador");
               volts = (int) JOptionPane.showInputDialog(null, "Agora informe a voltagem do equipamento", "FERNANDES ELETRO",0, null, volt, null);
               Liquidificador l = new Liquidificador(marca, volts);
               l.preço = Integer.parseInt(JOptionPane.showInputDialog("Diga o número do mês da compra"));
               l.getTampa().setCor(JOptionPane.showInputDialog("Diga a cor da tampa do liquidificador"));
               l.getTampa().setDescrição("Descreva a tampa");
               System.out.println("A marca do liquidificar é " +l.getMarca()+ "O preço é original:" +l.getPreço()+ "O preço com desconto"+l.CalcDesconto(8)+"A cor da tampa é:"+l.getTampa().getCor()+"A descrição é"+l.getTampa().getDescrição() );
           }
               if((eletro).equals("Batedeira")){
               String marca = JOptionPane.showInputDialog("Informe a marca da batedeira");
               volts = (int) JOptionPane.showInputDialog(null, "Agora informe a voltagem do equipamento", "FERNANDES ELETRO",0, null, volt2, null);
               Liquidificador l = new Liquidificador(marca, volts);
               l.setCapacidade(Integer.parseInt(JOptionPane.showInputDialog("Informe a capacidade de litros comportada pelo liquidificador")));
               l.setQuant(Integer.parseInt(JOptionPane.showInputDialog("Informe a quantidade de litros/segundos comportada pelo liquidificador ")));
               l.QuantidadeMedia(int quant, int capacidade);
               l.preço = Integer.parseInt(JOptionPane.showInputDialog("Diga o número do mês da compra"));
               l.getTampa().setCor(JOptionPane.showInputDialog("Diga a cor da tampa do liquidificador"));
               l.getTampa().setDescrição("Descreva a tampa");
               System.out.println("A marca do liquidificar é " +l.getMarca()+ "O preço é original:" +l.getPreço()+ "O preço com desconto"+l.CalcDesconto(8)+"A cor da tampa é:"+l.getTampa().getCor()+"A descrição é"+l.getTampa().getDescrição() );
            }
        }
    }
}





