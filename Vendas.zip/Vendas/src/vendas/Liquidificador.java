package vendas;
public class Liquidificador extends Eletrodomestico implements Helicoidal{
    private Tampa tampa;
    private int quant;
    private int capacidade;

    public int getQuant() {
        return quant;
    }

    public void setQuant(int quant) {
        this.quant = quant;
    }

    public int getCapacidade() {
        return capacidade;
    }

    public void setCapacidade(int capacidade) {
        this.capacidade = capacidade;
    }
    
    public Liquidificador(String marca, double preço, int voltagem) {
        super(marca, preço, voltagem);
        this.tampa = tampa;
    }
    public Liquidificador(String marca, int voltagem){
        super(marca, voltagem);
        this.tampa = tampa;
    }

    @Override
    public double CalcDesconto(int mes){
        if(mes == 8 ){
            this.preço = this.preço * 0.9f;   
        }return this.preço;
    }
    public Tampa getTampa() {
        return tampa;
    }

    public void setTampa(Tampa tampa) {
        this.tampa = tampa;
    }   

    @Override
    public float QuantidadeMedia(int quant, int capacidade) {
    return quant/capacidade;
        }
}

